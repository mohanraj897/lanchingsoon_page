import { useEffect } from "react";
import Navigation from "@/components/navigation";
import CountdownTimer from "@/components/countdown-timer";
import EmailSignup from "@/components/email-signup";
import FeatureCard from "@/components/feature-card";
import { 
  Briefcase, 
  Users, 
  DollarSign, 
  MessageSquare, 
  Link2, 
  Lightbulb,
  Mail,
  Phone,
  Headphones
} from "lucide-react";

const features = [
  {
    icon: Users,
    title: "Multiple Roles in One",
    color: "bg-purple-600",
    hoverColor: "hover:border-purple-500/50",
    features: [
      "Student & Learner",
      "Freelancer & Gig Worker",
      "Client & Project Manager",
      "Mentor & Developer"
    ]
  },
  {
    icon: DollarSign,
    title: "Multiple Income Paths",
    color: "bg-emerald-600",
    hoverColor: "hover:border-emerald-500/50",
    features: [
      "Traditional Job Placement",
      "Freelance Project Matching",
      "Product Sales Platform",
      "Client Services Hub"
    ]
  },
  {
    icon: MessageSquare,
    title: "Collaborative Community",
    color: "bg-blue-600",
    hoverColor: "hover:border-blue-500/50",
    features: [
      "Online work teams",
      "Peer support groups",
      "Mentorship matching",
      "Industry networking"
    ]
  },
  {
    icon: Lightbulb,
    title: "AI Tools",
    color: "bg-pink-600",
    hoverColor: "hover:border-pink-500/50",
    features: [
      "Personalized learning paths",
      "Smart skill assessments",
      "Career recommendations",
      "Business growth insights"
    ]
  },
  {
    icon: Briefcase,
    title: "Career Builder Module",
    color: "bg-indigo-600",
    hoverColor: "hover:border-indigo-500/50",
    features: [
      "Smart Job Alerts with AI suggestions",
      "Resume Analyzer + Builder",
      "Interview Scheduler with prep assistant",
      "Career Goal Tracker"
    ]
  },
  {
    icon: Link2,
    title: "Platform Integration",
    color: "bg-orange-600",
    hoverColor: "hover:border-orange-500/50",
    features: [
      "Zoom video conferencing",
      "Google Calendar sync",
      "LinkedIn networking",
      "Club community features"
    ]
  }
];

const testimonials = [
  {
    name: "Sarah Johnson",
    role: "Full-Stack Developer",
    initials: "SJ",
    color: "from-indigo-500 to-purple-500",
    quote: "Finally, a platform that understands the modern career journey. Can't wait for the full launch!"
  },
  {
    name: "Mike Rodriguez",
    role: "Startup Founder",
    initials: "MR",
    color: "from-emerald-500 to-blue-500",
    quote: "This will change how we think about career development and business growth. Revolutionary concept!"
  },
  {
    name: "Lisa Wang",
    role: "Freelance Designer",
    initials: "LW",
    color: "from-pink-500 to-orange-500",
    quote: "The AI-powered features are exactly what I need to take my freelance business to the next level."
  }
];

export default function Home() {
  useEffect(() => {
    // Set the page title
    document.title = "NextGenzcode - Coming Soon | The All-in-One Career, Business & Tech Service Super App";
    
    // Set meta description
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute('content', 'Build the ultimate digital-eco system where anyone can learn, earn, grow, and scale using one smart, AI-powered platform. Join the waitlist now!');
    } else {
      const newMeta = document.createElement('meta');
      newMeta.name = 'description';
      newMeta.content = 'Build the ultimate digital-eco system where anyone can learn, earn, grow, and scale using one smart, AI-powered platform. Founded by S. Mohanraj. Join the waitlist now!';
      document.head.appendChild(newMeta);
    }

    // Smooth scrolling for navigation links
    const handleAnchorClick = (e: Event) => {
      const target = e.target as HTMLAnchorElement;
      if (target.href && target.href.includes('#')) {
        e.preventDefault();
        const targetId = target.getAttribute('href')?.substring(1);
        const targetElement = document.getElementById(targetId || '');
        if (targetElement) {
          targetElement.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
          });
        }
      }
    };

    document.addEventListener('click', handleAnchorClick);
    return () => document.removeEventListener('click', handleAnchorClick);
  }, []);

  return (
    <div className="min-h-screen bg-slate-900 text-slate-50">
      <Navigation />
      
      {/* Hero Section */}
      <section className="min-h-screen flex items-center justify-center relative overflow-hidden pt-16">
        {/* Background Elements */}
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900"></div>
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center animate-fade-in">
            {/* Coming Soon Badge */}
            <div className="inline-flex items-center space-x-2 bg-indigo-600/20 border border-indigo-500/30 rounded-full px-6 py-2 mb-8">
              <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></div>
              <span className="text-indigo-300 font-medium">Coming Soon</span>
            </div>

            {/* Main Heading */}
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 bg-gradient-to-r from-white via-slate-200 to-slate-400 bg-clip-text text-transparent">
              The All-in-One Career,<br />
              Business & Tech<br />
              <span className="bg-gradient-to-r from-indigo-400 to-purple-400 bg-clip-text text-transparent">Service Super App</span>
            </h1>

            {/* Subtitle */}
            <p className="text-xl md:text-2xl text-slate-300 mb-8 max-w-4xl mx-auto leading-relaxed">
              Build the ultimate digital-eco system where anyone — a student, freelancer, job seeker, startup, or client — can{" "}
              <span className="text-emerald-400 font-semibold">learn, earn, grow, and scale</span> using one smart, AI-powered platform.
            </p>

            {/* Countdown Timer */}
            <div className="mb-12">
              <CountdownTimer />
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
              <button className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 px-8 py-4 rounded-xl font-semibold text-lg transition-all duration-300 transform hover:scale-105 animate-pulse-glow">
                Get Early Access
              </button>
              <button className="border border-slate-600 hover:border-slate-500 px-8 py-4 rounded-xl font-semibold text-lg transition-all duration-300 hover:bg-slate-800">
                Learn More
              </button>
            </div>

            {/* Progress Indicator */}
            <div className="max-w-md mx-auto">
              <div className="flex justify-between text-sm text-slate-400 mb-2">
                <span>Development Progress</span>
                <span>75%</span>
              </div>
              <div className="w-full bg-slate-800 rounded-full h-2">
                <div className="bg-gradient-to-r from-indigo-500 to-purple-500 h-2 rounded-full animate-pulse" style={{ width: '75%' }}></div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Key Features Section */}
      <section id="features" className="py-20 bg-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Key Features Across 5 Core Modules</h2>
            <p className="text-xl text-slate-300 max-w-3xl mx-auto">
              Unlike platforms that focus only on jobs or learning, NextGenzcode is a full stack solution that empowers users across every stage of their career or business journey.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <FeatureCard key={index} {...feature} />
            ))}
          </div>
        </div>
      </section>

      {/* Email Signup Section */}
      <section className="py-20 bg-slate-900">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Be the First to Experience NextGenzcode</h2>
          <p className="text-xl text-slate-300 mb-8 max-w-2xl mx-auto">
            Join our exclusive waitlist and get early access to the platform that will revolutionize how you build your career and business. Founded by S. Mohanraj with a vision to create the ultimate digital ecosystem.
          </p>
          
          <EmailSignup />

          {/* Social Proof */}
          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="text-2xl font-bold text-indigo-400">50K+</div>
              <div className="text-slate-400">Beta Signups</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-400">95%</div>
              <div className="text-slate-400">User Satisfaction</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-emerald-400">24/7</div>
              <div className="text-slate-400">AI Support</div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-16">What Early Users Are Saying</h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-slate-900 rounded-2xl p-8 border border-slate-700">
                <div className="flex items-center mb-4">
                  <div className={`w-12 h-12 bg-gradient-to-br ${testimonial.color} rounded-full flex items-center justify-center`}>
                    <span className="text-white font-semibold">{testimonial.initials}</span>
                  </div>
                  <div className="ml-4">
                    <div className="font-semibold">{testimonial.name}</div>
                    <div className="text-slate-400 text-sm">{testimonial.role}</div>
                  </div>
                </div>
                <p className="text-slate-300">{testimonial.quote}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-slate-900">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Get in Touch</h2>
          <p className="text-xl text-slate-300 mb-8">
            Have questions about NextGenzcode? We'd love to hear from you.
          </p>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-12 h-12 bg-indigo-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Mail className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-semibold mb-2">Email</h3>
              <p className="text-slate-400">rajm16772@gmail.com</p>
            </div>

            <div className="text-center">
              <div className="w-12 h-12 bg-purple-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Phone className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-semibold mb-2">Phone</h3>
              <p className="text-slate-400">+91 7603804916</p>
            </div>

            <div className="text-center">
              <div className="w-12 h-12 bg-emerald-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Headphones className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-semibold mb-2">Support</h3>
              <p className="text-slate-400">24/7 AI Assistant</p>
            </div>
          </div>

          {/* Social Media Links */}
          <div className="mt-12">
            <h3 className="text-lg font-semibold mb-6">Follow Us</h3>
            <div className="flex justify-center space-x-6">
              <a href="#" className="w-12 h-12 bg-slate-800 hover:bg-slate-700 rounded-xl flex items-center justify-center transition-colors">
                <svg className="w-5 h-5 text-slate-400 hover:text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z"/>
                </svg>
              </a>
              <a href="#" className="w-12 h-12 bg-slate-800 hover:bg-slate-700 rounded-xl flex items-center justify-center transition-colors">
                <svg className="w-5 h-5 text-slate-400 hover:text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                </svg>
              </a>
              <a href="#" className="w-12 h-12 bg-slate-800 hover:bg-slate-700 rounded-xl flex items-center justify-center transition-colors">
                <svg className="w-5 h-5 text-slate-400 hover:text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12.017 0C5.396 0 .029 5.367.029 11.987c0 5.079 3.158 9.417 7.618 11.174-.105-.949-.199-2.403.041-3.439.219-.937 1.406-5.957 1.406-5.957s-.359-.72-.359-1.781c0-1.663.967-2.911 2.168-2.911 1.024 0 1.518.769 1.518 1.688 0 1.029-.653 2.567-.992 3.992-.285 1.193.6 2.165 1.775 2.165 2.128 0 3.768-2.245 3.768-5.487 0-2.861-2.063-4.869-5.008-4.869-3.41 0-5.409 2.562-5.409 5.199 0 1.033.394 2.143.889 2.741.099.12.112.225.085.345-.09.375-.293 1.199-.334 1.363-.053.225-.172.271-.402.165-1.495-.69-2.433-2.878-2.433-4.646 0-3.776 2.748-7.252 7.92-7.252 4.158 0 7.392 2.967 7.392 6.923 0 4.135-2.607 7.462-6.233 7.462-1.214 0-2.357-.629-2.746-1.378l-.749 2.848c-.269 1.045-1.004 2.352-1.498 3.146 1.123.345 2.306.535 3.55.535 6.624 0 11.99-5.367 11.99-11.99C24.007 5.367 18.641.001 12.017.001z"/>
                </svg>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 border-t border-slate-800 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-2 mb-4 md:mb-0">
              <div className="w-8 h-8 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">NG</span>
              </div>
              <span className="text-xl font-bold text-white">NextGenzcode</span>
            </div>
            <div className="flex items-center space-x-6 text-slate-400">
              <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
              <span>&copy; 2024 NextGenzcode. All rights reserved. Founded by S. Mohanraj</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
