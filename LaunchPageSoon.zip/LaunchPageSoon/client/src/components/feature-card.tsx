import { LucideIcon } from "lucide-react";

interface FeatureCardProps {
  icon: LucideIcon;
  title: string;
  color: string;
  hoverColor: string;
  features: string[];
}

export default function FeatureCard({ icon: Icon, title, color, hoverColor, features }: FeatureCardProps) {
  return (
    <div className={`bg-slate-900 rounded-2xl p-8 border border-slate-700 ${hoverColor} transition-all duration-300 transform hover:-translate-y-2`}>
      <div className={`w-12 h-12 ${color} rounded-xl flex items-center justify-center mb-6`}>
        <Icon className="w-6 h-6 text-white" />
      </div>
      <h3 className="text-xl font-semibold mb-4">{title}</h3>
      <ul className="space-y-2 text-slate-300">
        {features.map((feature, index) => (
          <li key={index}>• {feature}</li>
        ))}
      </ul>
    </div>
  );
}
