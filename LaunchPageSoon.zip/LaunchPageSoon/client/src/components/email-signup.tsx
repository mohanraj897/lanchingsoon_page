import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function EmailSignup() {
  const [email, setEmail] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch waitlist count
  const { data: waitlistData } = useQuery({
    queryKey: ['/api/waitlist/count'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  // Email signup mutation
  const signupMutation = useMutation({
    mutationFn: async (email: string) => {
      const response = await apiRequest('POST', '/api/waitlist', { email });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Welcome to the waitlist! 🎉",
        description: "You'll be among the first to know when NextGenzcode launches. For quotations, please email rajm16772@gmail.com",
        variant: "default",
      });
      setEmail("");
      // Invalidate and refetch waitlist count
      queryClient.invalidateQueries({ queryKey: ['/api/waitlist/count'] });
    },
    onError: (error: any) => {
      let message = "Failed to join waitlist. Please try again.";
      
      if (error.message.includes("409")) {
        message = "You're already on our waitlist! 🎉";
      } else if (error.message.includes("400")) {
        message = "Please enter a valid email address.";
      }
      
      toast({
        title: "Signup Error",
        description: message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email && email.includes('@')) {
      signupMutation.mutate(email);
    } else {
      toast({
        title: "Invalid Email",
        description: "Please enter a valid email address.",
        variant: "destructive",
      });
    }
  };

  const waitlistCount = (waitlistData as { count: number })?.count || 2847;

  return (
    <div>
      <form onSubmit={handleSubmit} className="max-w-md mx-auto">
        <div className="flex flex-col sm:flex-row gap-4">
          <Input
            type="email"
            placeholder="Enter your email address"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="flex-1 px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none text-white placeholder-slate-400"
            required
          />
          <Button
            type="submit"
            disabled={signupMutation.isPending}
            className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 px-6 py-3 rounded-lg font-semibold whitespace-nowrap transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:transform-none"
          >
            {signupMutation.isPending ? "Joining..." : "Join Waitlist"}
          </Button>
        </div>
        <p className="text-sm text-slate-400 mt-4">
          🎉 <span className="font-semibold text-emerald-400">{waitlistCount.toLocaleString()}</span> professionals already on the waitlist!<br />
          For project quotations, email: <span className="text-indigo-400">rajm16772@gmail.com</span>
        </p>
      </form>
    </div>
  );
}
