import { useState, useEffect } from "react";

export default function CountdownTimer() {
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  });

  useEffect(() => {
    // Set launch date to 1.5 years from now
    const launchDate = new Date();
    launchDate.setMonth(launchDate.getMonth() + 18);

    const updateCountdown = () => {
      const now = new Date().getTime();
      const distance = launchDate.getTime() - now;

      if (distance < 0) {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
        return;
      }

      const days = Math.floor(distance / (1000 * 60 * 60 * 24));
      const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((distance % (1000 * 60)) / 1000);

      setTimeLeft({ days, hours, minutes, seconds });
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);

    return () => clearInterval(interval);
  }, []);

  if (timeLeft.days === 0 && timeLeft.hours === 0 && timeLeft.minutes === 0 && timeLeft.seconds === 0) {
    return (
      <div className="text-2xl font-bold text-emerald-400">
        🎉 We're Live!
      </div>
    );
  }

  return (
    <div className="flex justify-center space-x-4 md:space-x-8">
      <div className="text-center">
        <div className="text-3xl md:text-4xl font-bold text-indigo-400">{timeLeft.days}</div>
        <div className="text-sm text-slate-400">Days</div>
      </div>
      <div className="text-center">
        <div className="text-3xl md:text-4xl font-bold text-purple-400">{timeLeft.hours}</div>
        <div className="text-sm text-slate-400">Hours</div>
      </div>
      <div className="text-center">
        <div className="text-3xl md:text-4xl font-bold text-emerald-400">{timeLeft.minutes}</div>
        <div className="text-sm text-slate-400">Minutes</div>
      </div>
      <div className="text-center">
        <div className="text-3xl md:text-4xl font-bold text-orange-400">{timeLeft.seconds}</div>
        <div className="text-sm text-slate-400">Seconds</div>
      </div>
    </div>
  );
}
