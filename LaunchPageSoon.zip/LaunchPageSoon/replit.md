# NextGenzcode Platform

## Overview

NextGenzcode is a comprehensive career and freelancing platform built with a modern full-stack architecture. The application serves as a waitlist landing page for a multi-role platform that combines job searching, freelancing, mentoring, and project management capabilities. The system is designed to handle multiple user roles (students, freelancers, clients, mentors) and income streams within a single unified platform. Founded by S. Mohanraj with a vision to create the ultimate digital ecosystem.

## Recent Changes (July 29, 2025)

- Updated app name from "NextGencode" to "NextGenzcode" throughout the application
- Changed countdown timer from 3 months to 1.5 years (18 months) launch timeline
- Updated contact information: email (rajm16772@gmail.com) and phone (+91 7603804916)
- Reordered features per founder specifications: Multiple Roles → Multiple Income Paths → Collaborative Community → AI Tools → Career Builder Module → Platform Integration
- Added founder attribution (S. Mohanraj) in footer and meta descriptions
- Enhanced waitlist signup with project quotation contact information
- Fixed TypeScript error in email signup component
- Added PostgreSQL database integration with Drizzle ORM
- Migrated from in-memory storage to persistent database storage
- Successfully pushed schema to production database

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Framework**: Radix UI components with shadcn/ui design system
- **Styling**: Tailwind CSS with custom design tokens and dark mode support
- **Build Tool**: Vite for development and bundling

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API architecture
- **Middleware**: Custom logging, JSON parsing, and error handling
- **Development**: Hot reloading with Vite integration in development mode

### Database & ORM
- **Database**: PostgreSQL with Neon serverless hosting (production-ready)
- **ORM**: Drizzle ORM with type-safe queries and relations
- **Schema Management**: Drizzle Kit for schema migrations
- **Storage Layer**: DatabaseStorage class implementing IStorage interface
- **Connection**: Neon serverless pool with WebSocket support
- **Validation**: Zod schemas for runtime type validation

## Key Components

### Landing Page Features
- **Countdown Timer**: Dynamic countdown to platform launch (3 months from current date)
- **Email Waitlist**: Email collection system with validation and duplicate prevention
- **Feature Showcase**: Interactive cards displaying platform capabilities
- **Responsive Navigation**: Mobile-friendly navigation with smooth scrolling
- **Real-time Waitlist Counter**: Live updates of waitlist count

### Core Data Models
- **Users**: Basic user authentication structure (prepared for future expansion)
- **Waitlist Entries**: Email collection with timestamps and uniqueness constraints

### UI Component System
- **Design System**: Comprehensive shadcn/ui component library
- **Theming**: CSS custom properties with light/dark mode support
- **Responsive Design**: Mobile-first approach with Tailwind CSS
- **Accessibility**: ARIA-compliant components from Radix UI

## Data Flow

### Waitlist Registration Flow
1. User enters email on landing page
2. Frontend validates email format using Zod schema
3. TanStack Query mutation sends POST request to `/api/waitlist`
4. Backend validates data and checks for duplicates
5. Storage layer persists entry (memory in development, PostgreSQL in production)
6. Success response triggers UI feedback and counter update
7. Automatic counter refresh every 30 seconds

### Error Handling
- Client-side validation with immediate feedback
- Server-side validation with detailed error responses
- Graceful error handling with toast notifications
- Proper HTTP status codes (400, 409, 500)

## External Dependencies

### Database Services
- **Neon Database**: Serverless PostgreSQL hosting (@neondatabase/serverless)
- **Connection Pooling**: Built-in connection management for serverless environments

### UI & Styling
- **Radix UI**: Accessible, unstyled component primitives
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide React**: Icon library for consistent iconography
- **Class Variance Authority**: Type-safe variant management

### Development Tools
- **Replit Integration**: Custom Vite plugins for Replit environment
- **TypeScript**: Full type safety across frontend and backend
- **ESBuild**: Fast bundling for production builds

## Deployment Strategy

### Development Environment
- **Local Development**: Vite dev server with HMR
- **Storage**: In-memory storage for rapid development
- **Environment**: NODE_ENV=development with development-specific features

### Production Build
- **Frontend**: Vite build process generating static assets
- **Backend**: ESBuild bundling Node.js server for production
- **Database**: PostgreSQL via DATABASE_URL environment variable
- **Deployment**: Ready for Node.js hosting platforms

### Environment Configuration
- **Database URL**: Required for production database connection
- **Development Mode**: Automatic Replit integration when REPL_ID is present
- **Build Scripts**: Separate development and production command configurations

### Scalability Considerations
- **Database**: PostgreSQL supports horizontal scaling
- **API**: Stateless design enables load balancing
- **Frontend**: Static assets can be served via CDN
- **Storage**: Abstracted storage interface allows easy provider switching