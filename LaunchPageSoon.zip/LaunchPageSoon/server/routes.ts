import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertWaitlistEntrySchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get waitlist count
  app.get("/api/waitlist/count", async (req, res) => {
    try {
      const count = await storage.getWaitlistCount();
      res.json({ count });
    } catch (error) {
      res.status(500).json({ message: "Failed to get waitlist count" });
    }
  });

  // Add email to waitlist
  app.post("/api/waitlist", async (req, res) => {
    try {
      const validatedData = insertWaitlistEntrySchema.parse(req.body);
      const entry = await storage.addToWaitlist(validatedData);
      res.json({ 
        message: "Successfully added to waitlist",
        entry: { id: entry.id, email: entry.email }
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ 
          message: "Invalid email format",
          errors: error.errors 
        });
      } else if (error instanceof Error && error.message.includes("already registered")) {
        res.status(409).json({ message: "Email already registered for waitlist" });
      } else {
        res.status(500).json({ message: "Failed to add to waitlist" });
      }
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
